package main

import "fmt"

func main() {
	fmt.Println("Bonjour, tout le monde!")
}